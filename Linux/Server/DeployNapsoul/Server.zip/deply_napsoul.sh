#!/bin/bash

function echo_sucess {
    echo -e "\033[32m[DEPLOY-NAPSOUL] $(date "+%Y-%m-%d %H:%M:%S"): $1\033[0m"
}

function echo_failure {
    echo -e "\033[41;37m[DEPLOY-NAPSOUL] $(date "+%Y-%m-%d %H:%M:%S"): $1\033[0m"
}

function echo_warning {
    echo -e "\033[43;37m[DEPLOY-NAPSOUL] $(date "+%Y-%m-%d %H:%M:%S"): $1\033[0m"
}

function echo_separator {
    echo -e "\033[44;37m[DEPLOY-NAPSOUL] $(date "+%Y-%m-%d %H:%M:%S"): $1\033[0m"
}

function echo_info {
    echo -e "\033[40;37m[DEPLOY-NAPSOUL] $(date "+%Y-%m-%d %H:%M:%S"): $1\033[0m"
}

function new_line {
    echo -e "\n"
}

echo_separator "======================================================"
echo_sucess    "====           Deployment for napsoul.com         ===="
echo_separator "======================================================"

echo_sucess "Checking for ssl certs ..."
if [ ! -f "./ssl/fullchain.crt" ];then
  echo "SSL Certs dose not exists ..."
  read -p "PRESSING ENTER TO EXIT ... "
  exit 1
fi

echo_separator "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo_sucess    "~         Env Preparing         ~"
echo_separator "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

echo_sucess "Update apt repo ..."
sudo apt update

echo_sucess "Installing ca-certificates curl gnupg lsb-release ..."
sudo apt install -y ca-certificates curl gnupg lsb-release

echo_sucess "Config gpg ..."
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

echo_sucess "Update apt repo ..."
sudo apt update

echo_sucess "Installing docker ..."
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

echo_sucess "Testing docker installation ..."
sudo docker version

echo_sucess "Installing docker-compose ..."
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-pluginsudo curl -SL https://github.com/docker/compose/releases/download/v2.15.1/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
sudo curl -SL https://github.com/docker/compose/releases/download/v2.15.1/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

echo_sucess "Testing docker-compose installation ..."
sudo docker-compose version

echo_sucess "Handling docker user-group ..."
sudo groupadd docker
sudo usermod -aG docker $USER
newgrp docker

echo_separator "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
echo_sucess    "~         Build Services        ~"
echo_separator "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"

echo_sucess "Creating directories ..."
sudo mkdir -p /opt/nginx/{site,logs,conf,certs}

echo_sucess "Creating index.html ..."
cd /opt/nginx/site
sudo cat>index.html<<EOF
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>docker搭建nginx</title>
    </head>
    <body>
        <h1>docker搭建nginx映射成功</h1>
    </body>
</html>
EOF

echo_sucess "Creating nginx.conf ..."
cd /opt/nginx/conf
sudo cat>nginx.conf<<EOF
worker_processes  auto;

error_log  /var/log/nginx/error.log notice;
pid        /var/run/nginx.pid;

events {
    worker_connections  1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  text/plain;

    log_format  main  '\$remote_addr - \$remote_user [\$time_local] "\$request" '
                      '\$status \$body_bytes_sent "\$http_referer" '
                      '"\$http_user_agent" "\$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    #tcp_nopush     on;

    keepalive_timeout  65;

    #gzip  on;

    #include /etc/nginx/conf.d/*.conf;

    server {
        listen 80;
        server_name  napsoul.com;
        #root   /usr/share/nginx/html/;
        rewrite ^(.*)\$ https://\${server_name}\$1 permanent;
        #rewrite ^(.*)\$ https://\$host\$1 permanent;
    }

    server {
       listen 443 ssl http2;
       server_name napsoul.com;
       charset utf-8;

        ssl_certificate /etc/nginx/certs/fullchain.crt;
        ssl_certificate_key /etc/nginx/certs/private.pem;
        ssl_session_timeout 1d;
        ssl_session_cache shared:MozSSL:10m;
        ssl_session_tickets off;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
        ssl_prefer_server_ciphers off;
        ssl_stapling on;
        ssl_stapling_verify on;

       location / {
          root   /usr/share/nginx/html/;
          try_files \$uri \$uri/ =404;
          index  index.html index.htm;
       }

       #error_page  404              /404.html;

       # redirect server error pages to the static page /50x.html
       error_page   500 502 503 504  /50x.html;
       location = /50x.html {
           root   html;
       }
    }
}
EOF

echo_sucess "Creating docker-compose.yml ..."
cd /opt/nginx/
sudo cat>docker-compose.yml<<EOF
version: '3.3'

services:
  nginx:
    image: shreker/ql-nginx:1.23.3-0.1
    restart: always
    hostname: nginx
    container_name: nginx
    privileged: true
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - /opt/nginx/conf/nginx.conf:/etc/nginx/nginx.conf
      - /opt/nginx/site/:/usr/share/nginx/html/
      - /opt/nginx/logs/:/var/log/nginx/
      - /opt/nginx/certs/:/etc/nginx/certs/
EOF

echo_sucess "Copying ssl certs ..."
sudo cp ./ssl/* /opt/nginx/certs/

echo_sucess "Starting Docker ..."
docker-compose up -d

echo_sucess "Displaying logs ..."
docker logs nginx
